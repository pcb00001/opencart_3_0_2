<?php
// Heading

$_['text_latest']  		= 'Latest'; 
$_['text_comment']     	= ' Comment';
$_['text_comments']    	= ' Comments';
$_['text_view']        	= ' View';
$_['text_views']       	= ' Views';
// Text
$_['text_none_author'] 	= 'None Author';
$_['text_tax']      	= 'Ex Tax:';
$_['text_noitem']      	= 'Has no item to show!';
$_['text_no_database'] 	= 'Missing Database Tables for this Extension, Please Install "Simple Blog" Now!';