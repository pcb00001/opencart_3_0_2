<?php
// Heading 

// Text
$_['text_search_article']	= 'Search Article:';

// Buttons
$_['button_search']			= 'Search';