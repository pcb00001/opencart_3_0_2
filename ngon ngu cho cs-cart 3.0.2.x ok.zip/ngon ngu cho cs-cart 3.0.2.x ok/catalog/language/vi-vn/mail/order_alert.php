<?php
// Text
$_['text_subject']      = '%s - Đơn hàng %s';
$_['text_received']     = 'Bạn đã nhận được một đơn đặt hàng.';
$_['text_order_id']     = 'ID Đơn hàng:';
$_['text_date_added']   = 'Ngày tạo:';
$_['text_order_status'] = 'Tình trạng đơn hàng:';
$_['text_product']      = 'Sản phẩm';
$_['text_total']        = 'Tổng';
$_['text_comment']      = 'Nhận xét về đơn đặt hàng của bạn là:';
