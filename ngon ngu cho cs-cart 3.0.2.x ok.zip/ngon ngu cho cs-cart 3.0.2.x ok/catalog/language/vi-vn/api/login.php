<?php
// Text
$_['text_success'] = 'Thành công: bắt đầu thành công phiên API!';

// Error
$_['error_key']    = 'Cảnh báo: Khóa API không chính xác!';
$_['error_ip']     = 'Cảnh báo: IP của bạn %s không được phép truy cập vào API này!';