<?php
// Heading
$_['heading_title'] = 'Trang bạn yêu cầu không tồn tại!';

// Text
$_['text_error']    = 'Trang bạn yêu cầu không tồn tại!';