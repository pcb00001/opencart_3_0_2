<?php
// Heading
$_['heading_title']   = 'Quản lý tải về';

// Text
$_['text_account']    = 'Tài khoản';
$_['text_downloads']  = 'Tải về';
$_['text_empty']        = 'Bạn chưa thực hiện bất kỳ đơn hàng nào có thể tải xuống trước!';

// Column
$_['column_order_id']   = 'Thứ tự ID';
$_['column_name']       = 'Tên';
$_['column_size']       = 'Kích cỡ';
$_['column_date_added'] = 'Ngày đăng';