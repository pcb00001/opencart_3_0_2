<?php
// Heading
$_['heading_title']    = 'Đăng kí nhận thông báo';

// Text
$_['text_account']     = 'Tài khoản';
$_['text_newsletter']  = 'Thư thông báo';
$_['text_success']     = 'Thành công: Bạn đã đăng kí nhận thư thông báo!';

// Entry
$_['entry_newsletter'] = 'Đăng kí:';