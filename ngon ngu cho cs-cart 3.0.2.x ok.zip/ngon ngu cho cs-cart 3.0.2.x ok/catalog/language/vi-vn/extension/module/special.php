<?php
// Heading
$_['heading_title'] = 'Đặc biệt';

// Text
$_['text_tax']      = 'Ex Tax:';