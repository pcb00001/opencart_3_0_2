<?php
// Text
$_['text_captcha']  = 'Mã Captcha';

// Entry
$_['entry_captcha'] = 'Vui lòng hoàn tất việc xác nhận mã captcha bên dưới';

// Error
$_['error_captcha'] = 'Xác minh không chính xác!';