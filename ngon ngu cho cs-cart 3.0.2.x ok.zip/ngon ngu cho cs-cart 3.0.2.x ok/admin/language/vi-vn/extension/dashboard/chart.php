<?php
// Heading
$_['heading_title']    = 'Sales Analytics';

// Text
$_['text_extension']   = 'Tiện ích mở rộng';
$_['text_success']     = 'Thành công: Bạn đã sửa đổi bảng điều khiển bảng điều khiển!';
$_['text_edit']        = 'Chỉnh sửa Bảng điều khiển Biểu đồ';
$_['text_order']       = 'Đặt hàng';
$_['text_customer']    = 'Khách hàng';
$_['text_day']         = 'Hôm nay';
$_['text_week']        = 'Tuần';
$_['text_month']       = 'Tháng';
$_['text_year']        = 'Năm';

// Entry
$_['entry_status']     = 'Tình trạng';
$_['entry_sort_order'] = 'Thứ tự';
$_['entry_width']      = 'Ngang';
// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi bảng điều khiển bảng điều khiển!';