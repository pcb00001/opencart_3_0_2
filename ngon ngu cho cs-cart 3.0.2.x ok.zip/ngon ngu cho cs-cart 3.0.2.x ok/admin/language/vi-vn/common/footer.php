<?php
// Text
$_['text_footer']  = '<a href="http://www.thietkewebpn.com">Phiên bản tiếng việt thuộc bản quyền của thietkewebpn.com</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.';
$_['text_version'] = 'Phiên bản %s';