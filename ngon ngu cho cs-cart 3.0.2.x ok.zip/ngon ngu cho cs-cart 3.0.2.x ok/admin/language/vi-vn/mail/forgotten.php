<?php
// Text
$_['text_subject']  = '%s - Yêu cầu nhập lại mật khẩu';
$_['text_greeting'] = 'Một mật khẩu mới đã được yêu cầu %s Quản trị.';
$_['text_change']   = 'Để thiết lập lại mật khẩu của bạn nhấp vào liên kết bên dưới:';
$_['text_ip']       = 'IP đã được sử dụng để thực hiện yêu cầu này :';