<?php
// Text
$_['text_subject']  = '%s - Tài khoản Đại lý của bạn đã được kích hoạt!';
$_['text_welcome']  = 'Chào mừng và cảm ơn bạn đã đăng ký tại %s!';
$_['text_login']    = 'Tài khoản của bạn hiện đã được chấp thuận và bạn có thể đăng nhập bằng cách sử dụng địa chỉ email và mật khẩu bằng cách truy cập trang web của chúng tôi hoặc tại URL sau:';
$_['text_services'] = 'Khi đăng nhập, bạn sẽ có thể tạo mã theo dõi, theo dõi thanh toán hoa hồng và chỉnh sửa thông tin tài khoản của bạn.';
$_['text_thanks']   = 'Cảm Ơn,';