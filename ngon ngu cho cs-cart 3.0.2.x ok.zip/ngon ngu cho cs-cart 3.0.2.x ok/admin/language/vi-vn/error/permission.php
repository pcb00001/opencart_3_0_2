<?php
// Heading
$_['heading_title'] = 'Quyền hạn bị từ chối!';

// Text
$_['text_permission'] = 'Bạn không có quyền truy cập trang này, xin vui lòng liên hệ người quản trị hệ thống của bạn.';